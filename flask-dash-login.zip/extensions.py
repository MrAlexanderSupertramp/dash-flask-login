from flask_mail import Mail


mail = Mail()


# https://fierce-stream-40432.herokuapp.com/